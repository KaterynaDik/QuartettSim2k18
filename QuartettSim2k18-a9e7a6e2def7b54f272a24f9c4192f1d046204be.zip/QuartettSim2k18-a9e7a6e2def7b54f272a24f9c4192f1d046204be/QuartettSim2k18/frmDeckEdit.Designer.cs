﻿namespace QuartettSim2k18
{
    partial class frmDeckEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_Controls = new System.Windows.Forms.Panel();
            this.label_DeckLaden = new System.Windows.Forms.Label();
            this.label_NewDeck = new System.Windows.Forms.Label();
            this.panel_NewQuartett = new System.Windows.Forms.Panel();
            this.label_Caption = new System.Windows.Forms.Label();
            this.panel_KartenDef = new System.Windows.Forms.Panel();
            this.label_QuartettDef = new System.Windows.Forms.Label();
            this.label_Zwischenspeichern = new System.Windows.Forms.Label();
            this.panel_Karteninfos = new System.Windows.Forms.Panel();
            this.panel_KartenInhalte = new System.Windows.Forms.Panel();
            this.button_NextCard = new System.Windows.Forms.Button();
            this.textBox_CardName = new System.Windows.Forms.TextBox();
            this.button_BildWählen = new System.Windows.Forms.Button();
            this.pictureBox_Image = new System.Windows.Forms.PictureBox();
            this.textBox_DisplayValue6 = new System.Windows.Forms.TextBox();
            this.textBox_Value6 = new System.Windows.Forms.TextBox();
            this.label_P6 = new System.Windows.Forms.Label();
            this.textBox_DisplayValue5 = new System.Windows.Forms.TextBox();
            this.textBox_Value5 = new System.Windows.Forms.TextBox();
            this.label_P5 = new System.Windows.Forms.Label();
            this.textBox_DisplayValue4 = new System.Windows.Forms.TextBox();
            this.textBox_Value4 = new System.Windows.Forms.TextBox();
            this.label_P4 = new System.Windows.Forms.Label();
            this.textBox_DisplayValue3 = new System.Windows.Forms.TextBox();
            this.textBox_Value3 = new System.Windows.Forms.TextBox();
            this.label_P3 = new System.Windows.Forms.Label();
            this.textBox_DisplayValue2 = new System.Windows.Forms.TextBox();
            this.textBox_Value2 = new System.Windows.Forms.TextBox();
            this.label_P2 = new System.Windows.Forms.Label();
            this.textBox_DisplayValue1 = new System.Windows.Forms.TextBox();
            this.textBox_Value1 = new System.Windows.Forms.TextBox();
            this.label_P1 = new System.Windows.Forms.Label();
            this.label_Kartennummer = new System.Windows.Forms.Label();
            this.button_NextQuartett = new System.Windows.Forms.Button();
            this.textBox_Quartettname = new System.Windows.Forms.TextBox();
            this.label_Quartettname = new System.Windows.Forms.Label();
            this.panel_QuartettDef = new System.Windows.Forms.Panel();
            this.panel_Eigenschaft6 = new System.Windows.Forms.Panel();
            this.checkButton_BiB6 = new DevExpress.XtraEditors.CheckButton();
            this.textBox_Eigenschaft6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel_Eigenschaft5 = new System.Windows.Forms.Panel();
            this.checkButton_BiB5 = new DevExpress.XtraEditors.CheckButton();
            this.textBox_Eigenschaft5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel_Eigenschaft4 = new System.Windows.Forms.Panel();
            this.checkButton_BiB4 = new DevExpress.XtraEditors.CheckButton();
            this.textBox_Eigenschaft4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_Eigenschaft3 = new System.Windows.Forms.Panel();
            this.checkButton_BiB3 = new DevExpress.XtraEditors.CheckButton();
            this.textBox_Eigenschaft3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_Eigenschaft2 = new System.Windows.Forms.Panel();
            this.checkButton_BiB = new DevExpress.XtraEditors.CheckButton();
            this.textBox_Eigenschaft2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_Eigenschaft1 = new System.Windows.Forms.Panel();
            this.checkButton_BiB1 = new DevExpress.XtraEditors.CheckButton();
            this.textBox_Eigenschaft1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label_Karten = new System.Windows.Forms.Label();
            this.label_Deckeigenschaften = new System.Windows.Forms.Label();
            this.panel_Eigenschaften = new System.Windows.Forms.Panel();
            this.label_QuartetteDefinieren = new System.Windows.Forms.Label();
            this.label_SpeicherortWählen = new System.Windows.Forms.Label();
            this.label_SpeicherortValue = new System.Windows.Forms.Label();
            this.label_Speicherort = new System.Windows.Forms.Label();
            this.label_DeckName = new System.Windows.Forms.Label();
            this.label_AnzahlEigenschaften = new System.Windows.Forms.Label();
            this.numericUpDown_AnzahlQuartetts = new System.Windows.Forms.NumericUpDown();
            this.label_AnzahlQuartetts = new System.Windows.Forms.Label();
            this.numericUpDown_AnzahlEiggenschaften = new System.Windows.Forms.NumericUpDown();
            this.textBox_DeckName = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog_Speicherort = new System.Windows.Forms.FolderBrowserDialog();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel_Controls.SuspendLayout();
            this.panel_NewQuartett.SuspendLayout();
            this.panel_KartenDef.SuspendLayout();
            this.panel_Karteninfos.SuspendLayout();
            this.panel_KartenInhalte.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Image)).BeginInit();
            this.panel_QuartettDef.SuspendLayout();
            this.panel_Eigenschaft6.SuspendLayout();
            this.panel_Eigenschaft5.SuspendLayout();
            this.panel_Eigenschaft4.SuspendLayout();
            this.panel_Eigenschaft3.SuspendLayout();
            this.panel_Eigenschaft2.SuspendLayout();
            this.panel_Eigenschaft1.SuspendLayout();
            this.panel_Eigenschaften.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_AnzahlQuartetts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_AnzahlEiggenschaften)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Controls
            // 
            this.panel_Controls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Controls.Controls.Add(this.label_DeckLaden);
            this.panel_Controls.Controls.Add(this.label_NewDeck);
            this.panel_Controls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Controls.Location = new System.Drawing.Point(0, 400);
            this.panel_Controls.Margin = new System.Windows.Forms.Padding(8);
            this.panel_Controls.Name = "panel_Controls";
            this.panel_Controls.Size = new System.Drawing.Size(521, 78);
            this.panel_Controls.TabIndex = 0;
            // 
            // label_DeckLaden
            // 
            this.label_DeckLaden.Dock = System.Windows.Forms.DockStyle.Left;
            this.label_DeckLaden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_DeckLaden.ForeColor = System.Drawing.Color.AliceBlue;
            this.label_DeckLaden.Location = new System.Drawing.Point(247, 0);
            this.label_DeckLaden.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label_DeckLaden.Name = "label_DeckLaden";
            this.label_DeckLaden.Size = new System.Drawing.Size(273, 76);
            this.label_DeckLaden.TabIndex = 1;
            this.label_DeckLaden.Text = "Deck Laden";
            this.label_DeckLaden.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_DeckLaden.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_DeckLaden.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // label_NewDeck
            // 
            this.label_NewDeck.Dock = System.Windows.Forms.DockStyle.Left;
            this.label_NewDeck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NewDeck.ForeColor = System.Drawing.Color.AliceBlue;
            this.label_NewDeck.Location = new System.Drawing.Point(0, 0);
            this.label_NewDeck.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label_NewDeck.Name = "label_NewDeck";
            this.label_NewDeck.Size = new System.Drawing.Size(247, 76);
            this.label_NewDeck.TabIndex = 0;
            this.label_NewDeck.Text = "Neues Deck";
            this.label_NewDeck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_NewDeck.Click += new System.EventHandler(this.label_NewDeck_Click);
            this.label_NewDeck.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_NewDeck.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // panel_NewQuartett
            // 
            this.panel_NewQuartett.Controls.Add(this.label_Caption);
            this.panel_NewQuartett.Controls.Add(this.panel_KartenDef);
            this.panel_NewQuartett.Controls.Add(this.panel_QuartettDef);
            this.panel_NewQuartett.Controls.Add(this.panel_Eigenschaften);
            this.panel_NewQuartett.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_NewQuartett.Location = new System.Drawing.Point(0, 0);
            this.panel_NewQuartett.Name = "panel_NewQuartett";
            this.panel_NewQuartett.Size = new System.Drawing.Size(521, 400);
            this.panel_NewQuartett.TabIndex = 1;
            this.panel_NewQuartett.Visible = false;
            // 
            // label_Caption
            // 
            this.label_Caption.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_Caption.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_Caption.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Caption.Location = new System.Drawing.Point(0, 0);
            this.label_Caption.Name = "label_Caption";
            this.label_Caption.Size = new System.Drawing.Size(521, 37);
            this.label_Caption.TabIndex = 2;
            this.label_Caption.Text = "Deckeigenschaften";
            this.label_Caption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_KartenDef
            // 
            this.panel_KartenDef.Controls.Add(this.label_QuartettDef);
            this.panel_KartenDef.Controls.Add(this.label_Zwischenspeichern);
            this.panel_KartenDef.Controls.Add(this.panel_Karteninfos);
            this.panel_KartenDef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_KartenDef.Location = new System.Drawing.Point(0, 0);
            this.panel_KartenDef.Name = "panel_KartenDef";
            this.panel_KartenDef.Size = new System.Drawing.Size(521, 400);
            this.panel_KartenDef.TabIndex = 8;
            this.panel_KartenDef.Tag = "3";
            this.panel_KartenDef.Visible = false;
            // 
            // label_QuartettDef
            // 
            this.label_QuartettDef.Location = new System.Drawing.Point(3, 364);
            this.label_QuartettDef.Name = "label_QuartettDef";
            this.label_QuartettDef.Size = new System.Drawing.Size(221, 37);
            this.label_QuartettDef.TabIndex = 2;
            this.label_QuartettDef.Tag = "2";
            this.label_QuartettDef.Text = "< Quartett Def.";
            this.label_QuartettDef.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_QuartettDef.Click += new System.EventHandler(this.label_QuartetteDefinieren_Click);
            this.label_QuartettDef.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_QuartettDef.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // label_Zwischenspeichern
            // 
            this.label_Zwischenspeichern.Location = new System.Drawing.Point(0, 42);
            this.label_Zwischenspeichern.Name = "label_Zwischenspeichern";
            this.label_Zwischenspeichern.Size = new System.Drawing.Size(521, 37);
            this.label_Zwischenspeichern.TabIndex = 0;
            this.label_Zwischenspeichern.Text = "Zwischenspeichern zum Fortfahren";
            this.label_Zwischenspeichern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_Zwischenspeichern.Click += new System.EventHandler(this.label_Zwischenspeichern_Click);
            this.label_Zwischenspeichern.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_Zwischenspeichern.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // panel_Karteninfos
            // 
            this.panel_Karteninfos.Controls.Add(this.panel_KartenInhalte);
            this.panel_Karteninfos.Controls.Add(this.button_NextQuartett);
            this.panel_Karteninfos.Controls.Add(this.textBox_Quartettname);
            this.panel_Karteninfos.Controls.Add(this.label_Quartettname);
            this.panel_Karteninfos.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Karteninfos.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_Karteninfos.Location = new System.Drawing.Point(0, 0);
            this.panel_Karteninfos.Name = "panel_Karteninfos";
            this.panel_Karteninfos.Size = new System.Drawing.Size(521, 361);
            this.panel_Karteninfos.TabIndex = 1;
            this.panel_Karteninfos.Visible = false;
            // 
            // panel_KartenInhalte
            // 
            this.panel_KartenInhalte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(31)))), ((int)(((byte)(129)))));
            this.panel_KartenInhalte.Controls.Add(this.button_NextCard);
            this.panel_KartenInhalte.Controls.Add(this.textBox_CardName);
            this.panel_KartenInhalte.Controls.Add(this.button_BildWählen);
            this.panel_KartenInhalte.Controls.Add(this.pictureBox_Image);
            this.panel_KartenInhalte.Controls.Add(this.textBox_DisplayValue6);
            this.panel_KartenInhalte.Controls.Add(this.textBox_Value6);
            this.panel_KartenInhalte.Controls.Add(this.label_P6);
            this.panel_KartenInhalte.Controls.Add(this.textBox_DisplayValue5);
            this.panel_KartenInhalte.Controls.Add(this.textBox_Value5);
            this.panel_KartenInhalte.Controls.Add(this.label_P5);
            this.panel_KartenInhalte.Controls.Add(this.textBox_DisplayValue4);
            this.panel_KartenInhalte.Controls.Add(this.textBox_Value4);
            this.panel_KartenInhalte.Controls.Add(this.label_P4);
            this.panel_KartenInhalte.Controls.Add(this.textBox_DisplayValue3);
            this.panel_KartenInhalte.Controls.Add(this.textBox_Value3);
            this.panel_KartenInhalte.Controls.Add(this.label_P3);
            this.panel_KartenInhalte.Controls.Add(this.textBox_DisplayValue2);
            this.panel_KartenInhalte.Controls.Add(this.textBox_Value2);
            this.panel_KartenInhalte.Controls.Add(this.label_P2);
            this.panel_KartenInhalte.Controls.Add(this.textBox_DisplayValue1);
            this.panel_KartenInhalte.Controls.Add(this.textBox_Value1);
            this.panel_KartenInhalte.Controls.Add(this.label_P1);
            this.panel_KartenInhalte.Controls.Add(this.label_Kartennummer);
            this.panel_KartenInhalte.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_KartenInhalte.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_KartenInhalte.Location = new System.Drawing.Point(0, 121);
            this.panel_KartenInhalte.Name = "panel_KartenInhalte";
            this.panel_KartenInhalte.Size = new System.Drawing.Size(521, 240);
            this.panel_KartenInhalte.TabIndex = 3;
            // 
            // button_NextCard
            // 
            this.button_NextCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_NextCard.Location = new System.Drawing.Point(356, 199);
            this.button_NextCard.Name = "button_NextCard";
            this.button_NextCard.Size = new System.Drawing.Size(153, 30);
            this.button_NextCard.TabIndex = 22;
            this.button_NextCard.Text = "Nächste Karte";
            this.button_NextCard.UseVisualStyleBackColor = true;
            this.button_NextCard.Click += new System.EventHandler(this.button_NextCard_Click);
            // 
            // textBox_CardName
            // 
            this.textBox_CardName.Location = new System.Drawing.Point(355, 32);
            this.textBox_CardName.Name = "textBox_CardName";
            this.textBox_CardName.Size = new System.Drawing.Size(150, 27);
            this.textBox_CardName.TabIndex = 21;
            this.textBox_CardName.Tag = "";
            this.textBox_CardName.Text = "Kartenname";
            // 
            // button_BildWählen
            // 
            this.button_BildWählen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_BildWählen.Location = new System.Drawing.Point(356, 163);
            this.button_BildWählen.Name = "button_BildWählen";
            this.button_BildWählen.Size = new System.Drawing.Size(153, 30);
            this.button_BildWählen.TabIndex = 20;
            this.button_BildWählen.Text = "Bild auswählen";
            this.button_BildWählen.UseVisualStyleBackColor = true;
            this.button_BildWählen.Click += new System.EventHandler(this.button_BildWählen_Click);
            // 
            // pictureBox_Image
            // 
            this.pictureBox_Image.BackColor = System.Drawing.Color.White;
            this.pictureBox_Image.Location = new System.Drawing.Point(355, 67);
            this.pictureBox_Image.Name = "pictureBox_Image";
            this.pictureBox_Image.Size = new System.Drawing.Size(150, 91);
            this.pictureBox_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Image.TabIndex = 19;
            this.pictureBox_Image.TabStop = false;
            // 
            // textBox_DisplayValue6
            // 
            this.textBox_DisplayValue6.Location = new System.Drawing.Point(197, 196);
            this.textBox_DisplayValue6.Name = "textBox_DisplayValue6";
            this.textBox_DisplayValue6.Size = new System.Drawing.Size(94, 27);
            this.textBox_DisplayValue6.TabIndex = 18;
            this.textBox_DisplayValue6.Tag = "6";
            this.textBox_DisplayValue6.Text = "DisplayValue";
            // 
            // textBox_Value6
            // 
            this.textBox_Value6.Location = new System.Drawing.Point(124, 196);
            this.textBox_Value6.Name = "textBox_Value6";
            this.textBox_Value6.Size = new System.Drawing.Size(67, 27);
            this.textBox_Value6.TabIndex = 17;
            this.textBox_Value6.Tag = "6";
            this.textBox_Value6.Text = "Value";
            // 
            // label_P6
            // 
            this.label_P6.Location = new System.Drawing.Point(12, 196);
            this.label_P6.Name = "label_P6";
            this.label_P6.Size = new System.Drawing.Size(106, 25);
            this.label_P6.TabIndex = 16;
            this.label_P6.Tag = "6";
            this.label_P6.Text = "Property6";
            // 
            // textBox_DisplayValue5
            // 
            this.textBox_DisplayValue5.Location = new System.Drawing.Point(197, 163);
            this.textBox_DisplayValue5.Name = "textBox_DisplayValue5";
            this.textBox_DisplayValue5.Size = new System.Drawing.Size(94, 27);
            this.textBox_DisplayValue5.TabIndex = 15;
            this.textBox_DisplayValue5.Tag = "5";
            this.textBox_DisplayValue5.Text = "DisplayValue";
            // 
            // textBox_Value5
            // 
            this.textBox_Value5.Location = new System.Drawing.Point(124, 163);
            this.textBox_Value5.Name = "textBox_Value5";
            this.textBox_Value5.Size = new System.Drawing.Size(67, 27);
            this.textBox_Value5.TabIndex = 14;
            this.textBox_Value5.Tag = "5";
            this.textBox_Value5.Text = "Value";
            // 
            // label_P5
            // 
            this.label_P5.Location = new System.Drawing.Point(12, 165);
            this.label_P5.Name = "label_P5";
            this.label_P5.Size = new System.Drawing.Size(106, 25);
            this.label_P5.TabIndex = 13;
            this.label_P5.Tag = "5";
            this.label_P5.Text = "Property5";
            // 
            // textBox_DisplayValue4
            // 
            this.textBox_DisplayValue4.Location = new System.Drawing.Point(197, 131);
            this.textBox_DisplayValue4.Name = "textBox_DisplayValue4";
            this.textBox_DisplayValue4.Size = new System.Drawing.Size(94, 27);
            this.textBox_DisplayValue4.TabIndex = 12;
            this.textBox_DisplayValue4.Tag = "4";
            this.textBox_DisplayValue4.Text = "DisplayValue";
            // 
            // textBox_Value4
            // 
            this.textBox_Value4.Location = new System.Drawing.Point(124, 131);
            this.textBox_Value4.Name = "textBox_Value4";
            this.textBox_Value4.Size = new System.Drawing.Size(67, 27);
            this.textBox_Value4.TabIndex = 11;
            this.textBox_Value4.Tag = "4";
            this.textBox_Value4.Text = "Value";
            // 
            // label_P4
            // 
            this.label_P4.Location = new System.Drawing.Point(12, 133);
            this.label_P4.Name = "label_P4";
            this.label_P4.Size = new System.Drawing.Size(106, 25);
            this.label_P4.TabIndex = 10;
            this.label_P4.Tag = "4";
            this.label_P4.Text = "Property4";
            // 
            // textBox_DisplayValue3
            // 
            this.textBox_DisplayValue3.Location = new System.Drawing.Point(197, 98);
            this.textBox_DisplayValue3.Name = "textBox_DisplayValue3";
            this.textBox_DisplayValue3.Size = new System.Drawing.Size(94, 27);
            this.textBox_DisplayValue3.TabIndex = 9;
            this.textBox_DisplayValue3.Tag = "3";
            this.textBox_DisplayValue3.Text = "DisplayValue";
            // 
            // textBox_Value3
            // 
            this.textBox_Value3.Location = new System.Drawing.Point(124, 98);
            this.textBox_Value3.Name = "textBox_Value3";
            this.textBox_Value3.Size = new System.Drawing.Size(67, 27);
            this.textBox_Value3.TabIndex = 8;
            this.textBox_Value3.Tag = "3";
            this.textBox_Value3.Text = "Value";
            // 
            // label_P3
            // 
            this.label_P3.Location = new System.Drawing.Point(12, 100);
            this.label_P3.Name = "label_P3";
            this.label_P3.Size = new System.Drawing.Size(106, 25);
            this.label_P3.TabIndex = 7;
            this.label_P3.Tag = "3";
            this.label_P3.Text = "Property3";
            // 
            // textBox_DisplayValue2
            // 
            this.textBox_DisplayValue2.Location = new System.Drawing.Point(197, 65);
            this.textBox_DisplayValue2.Name = "textBox_DisplayValue2";
            this.textBox_DisplayValue2.Size = new System.Drawing.Size(94, 27);
            this.textBox_DisplayValue2.TabIndex = 6;
            this.textBox_DisplayValue2.Tag = "2";
            this.textBox_DisplayValue2.Text = "DisplayValue";
            // 
            // textBox_Value2
            // 
            this.textBox_Value2.Location = new System.Drawing.Point(124, 65);
            this.textBox_Value2.Name = "textBox_Value2";
            this.textBox_Value2.Size = new System.Drawing.Size(67, 27);
            this.textBox_Value2.TabIndex = 5;
            this.textBox_Value2.Tag = "2";
            this.textBox_Value2.Text = "Value";
            // 
            // label_P2
            // 
            this.label_P2.Location = new System.Drawing.Point(12, 67);
            this.label_P2.Name = "label_P2";
            this.label_P2.Size = new System.Drawing.Size(106, 25);
            this.label_P2.TabIndex = 4;
            this.label_P2.Tag = "2";
            this.label_P2.Text = "Property2";
            // 
            // textBox_DisplayValue1
            // 
            this.textBox_DisplayValue1.Location = new System.Drawing.Point(197, 32);
            this.textBox_DisplayValue1.Name = "textBox_DisplayValue1";
            this.textBox_DisplayValue1.Size = new System.Drawing.Size(94, 27);
            this.textBox_DisplayValue1.TabIndex = 3;
            this.textBox_DisplayValue1.Tag = "1";
            this.textBox_DisplayValue1.Text = "DisplayValue";
            // 
            // textBox_Value1
            // 
            this.textBox_Value1.Location = new System.Drawing.Point(124, 32);
            this.textBox_Value1.Name = "textBox_Value1";
            this.textBox_Value1.Size = new System.Drawing.Size(67, 27);
            this.textBox_Value1.TabIndex = 2;
            this.textBox_Value1.Tag = "1";
            this.textBox_Value1.Text = "Value";
            // 
            // label_P1
            // 
            this.label_P1.Location = new System.Drawing.Point(12, 34);
            this.label_P1.Name = "label_P1";
            this.label_P1.Size = new System.Drawing.Size(106, 25);
            this.label_P1.TabIndex = 1;
            this.label_P1.Tag = "1";
            this.label_P1.Text = "Property1";
            // 
            // label_Kartennummer
            // 
            this.label_Kartennummer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(31)))), ((int)(((byte)(129)))));
            this.label_Kartennummer.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_Kartennummer.Location = new System.Drawing.Point(0, 0);
            this.label_Kartennummer.Name = "label_Kartennummer";
            this.label_Kartennummer.Size = new System.Drawing.Size(521, 25);
            this.label_Kartennummer.TabIndex = 0;
            this.label_Kartennummer.Text = "Karte 1";
            this.label_Kartennummer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_NextQuartett
            // 
            this.button_NextQuartett.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_NextQuartett.Location = new System.Drawing.Point(396, 81);
            this.button_NextQuartett.Name = "button_NextQuartett";
            this.button_NextQuartett.Size = new System.Drawing.Size(112, 34);
            this.button_NextQuartett.TabIndex = 2;
            this.button_NextQuartett.Text = "Nächstes";
            this.button_NextQuartett.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_NextQuartett.UseVisualStyleBackColor = true;
            this.button_NextQuartett.Click += new System.EventHandler(this.button_NextQuartett_Click);
            // 
            // textBox_Quartettname
            // 
            this.textBox_Quartettname.Location = new System.Drawing.Point(171, 79);
            this.textBox_Quartettname.Name = "textBox_Quartettname";
            this.textBox_Quartettname.Size = new System.Drawing.Size(219, 36);
            this.textBox_Quartettname.TabIndex = 1;
            // 
            // label_Quartettname
            // 
            this.label_Quartettname.AutoSize = true;
            this.label_Quartettname.Location = new System.Drawing.Point(12, 79);
            this.label_Quartettname.Name = "label_Quartettname";
            this.label_Quartettname.Size = new System.Drawing.Size(153, 30);
            this.label_Quartettname.TabIndex = 0;
            this.label_Quartettname.Text = "Quartettname:";
            // 
            // panel_QuartettDef
            // 
            this.panel_QuartettDef.Controls.Add(this.panel_Eigenschaft6);
            this.panel_QuartettDef.Controls.Add(this.panel_Eigenschaft5);
            this.panel_QuartettDef.Controls.Add(this.panel_Eigenschaft4);
            this.panel_QuartettDef.Controls.Add(this.panel_Eigenschaft3);
            this.panel_QuartettDef.Controls.Add(this.panel_Eigenschaft2);
            this.panel_QuartettDef.Controls.Add(this.panel_Eigenschaft1);
            this.panel_QuartettDef.Controls.Add(this.label_Karten);
            this.panel_QuartettDef.Controls.Add(this.label_Deckeigenschaften);
            this.panel_QuartettDef.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_QuartettDef.Location = new System.Drawing.Point(0, 0);
            this.panel_QuartettDef.Name = "panel_QuartettDef";
            this.panel_QuartettDef.Size = new System.Drawing.Size(521, 400);
            this.panel_QuartettDef.TabIndex = 11;
            this.panel_QuartettDef.Tag = "2";
            this.panel_QuartettDef.Visible = false;
            this.panel_QuartettDef.VisibleChanged += new System.EventHandler(this.panel_QuartettDef_VisibleChanged);
            // 
            // panel_Eigenschaft6
            // 
            this.panel_Eigenschaft6.Controls.Add(this.checkButton_BiB6);
            this.panel_Eigenschaft6.Controls.Add(this.textBox_Eigenschaft6);
            this.panel_Eigenschaft6.Controls.Add(this.label6);
            this.panel_Eigenschaft6.Location = new System.Drawing.Point(17, 268);
            this.panel_Eigenschaft6.Name = "panel_Eigenschaft6";
            this.panel_Eigenschaft6.Size = new System.Drawing.Size(491, 38);
            this.panel_Eigenschaft6.TabIndex = 7;
            this.panel_Eigenschaft6.Tag = "6";
            // 
            // checkButton_BiB6
            // 
            this.checkButton_BiB6.AppearancePressed.BackColor = System.Drawing.Color.DarkMagenta;
            this.checkButton_BiB6.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.checkButton_BiB6.AppearancePressed.Options.UseBackColor = true;
            this.checkButton_BiB6.AppearancePressed.Options.UseForeColor = true;
            this.checkButton_BiB6.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.checkButton_BiB6.Checked = true;
            this.checkButton_BiB6.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkButton_BiB6.Location = new System.Drawing.Point(392, 0);
            this.checkButton_BiB6.Name = "checkButton_BiB6";
            this.checkButton_BiB6.Size = new System.Drawing.Size(96, 38);
            this.checkButton_BiB6.TabIndex = 3;
            this.checkButton_BiB6.Tag = "6";
            this.checkButton_BiB6.Text = "Größer ist besser";
            this.checkButton_BiB6.ToolTip = "Wenn dieses Element gesetzt ist, dann gewinnt bei einem Vergleich dieser Eigensch" +
    "aft\r\nimmer derjenige mit dem größeren Wert.\r\nDas wäre zum Beispiel beim Autoquar" +
    "tett bei der Fahrzeugleistung der Fall.";
            this.checkButton_BiB6.ToolTipAnchor = DevExpress.Utils.ToolTipAnchor.Object;
            this.checkButton_BiB6.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // textBox_Eigenschaft6
            // 
            this.textBox_Eigenschaft6.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox_Eigenschaft6.Location = new System.Drawing.Point(180, 0);
            this.textBox_Eigenschaft6.Name = "textBox_Eigenschaft6";
            this.textBox_Eigenschaft6.Size = new System.Drawing.Size(212, 43);
            this.textBox_Eigenschaft6.TabIndex = 1;
            this.textBox_Eigenschaft6.Tag = "6";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(180, 37);
            this.label6.TabIndex = 0;
            this.label6.Text = "Eigenschaft 6:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Eigenschaft5
            // 
            this.panel_Eigenschaft5.Controls.Add(this.checkButton_BiB5);
            this.panel_Eigenschaft5.Controls.Add(this.textBox_Eigenschaft5);
            this.panel_Eigenschaft5.Controls.Add(this.label5);
            this.panel_Eigenschaft5.Location = new System.Drawing.Point(17, 224);
            this.panel_Eigenschaft5.Name = "panel_Eigenschaft5";
            this.panel_Eigenschaft5.Size = new System.Drawing.Size(491, 38);
            this.panel_Eigenschaft5.TabIndex = 7;
            this.panel_Eigenschaft5.Tag = "5";
            // 
            // checkButton_BiB5
            // 
            this.checkButton_BiB5.AppearancePressed.BackColor = System.Drawing.Color.DarkMagenta;
            this.checkButton_BiB5.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.checkButton_BiB5.AppearancePressed.Options.UseBackColor = true;
            this.checkButton_BiB5.AppearancePressed.Options.UseForeColor = true;
            this.checkButton_BiB5.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.checkButton_BiB5.Checked = true;
            this.checkButton_BiB5.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkButton_BiB5.Location = new System.Drawing.Point(392, 0);
            this.checkButton_BiB5.Name = "checkButton_BiB5";
            this.checkButton_BiB5.Size = new System.Drawing.Size(96, 38);
            this.checkButton_BiB5.TabIndex = 3;
            this.checkButton_BiB5.Tag = "5";
            this.checkButton_BiB5.Text = "Größer ist besser";
            this.checkButton_BiB5.ToolTip = "Wenn dieses Element gesetzt ist, dann gewinnt bei einem Vergleich dieser Eigensch" +
    "aft\r\nimmer derjenige mit dem größeren Wert.\r\nDas wäre zum Beispiel beim Autoquar" +
    "tett bei der Fahrzeugleistung der Fall.";
            this.checkButton_BiB5.ToolTipAnchor = DevExpress.Utils.ToolTipAnchor.Object;
            this.checkButton_BiB5.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // textBox_Eigenschaft5
            // 
            this.textBox_Eigenschaft5.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox_Eigenschaft5.Location = new System.Drawing.Point(180, 0);
            this.textBox_Eigenschaft5.Name = "textBox_Eigenschaft5";
            this.textBox_Eigenschaft5.Size = new System.Drawing.Size(212, 43);
            this.textBox_Eigenschaft5.TabIndex = 1;
            this.textBox_Eigenschaft5.Tag = "5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 37);
            this.label5.TabIndex = 0;
            this.label5.Tag = "5";
            this.label5.Text = "Eigenschaft 5:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Eigenschaft4
            // 
            this.panel_Eigenschaft4.Controls.Add(this.checkButton_BiB4);
            this.panel_Eigenschaft4.Controls.Add(this.textBox_Eigenschaft4);
            this.panel_Eigenschaft4.Controls.Add(this.label4);
            this.panel_Eigenschaft4.Location = new System.Drawing.Point(17, 180);
            this.panel_Eigenschaft4.Name = "panel_Eigenschaft4";
            this.panel_Eigenschaft4.Size = new System.Drawing.Size(491, 38);
            this.panel_Eigenschaft4.TabIndex = 6;
            this.panel_Eigenschaft4.Tag = "4";
            // 
            // checkButton_BiB4
            // 
            this.checkButton_BiB4.AppearancePressed.BackColor = System.Drawing.Color.DarkMagenta;
            this.checkButton_BiB4.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.checkButton_BiB4.AppearancePressed.Options.UseBackColor = true;
            this.checkButton_BiB4.AppearancePressed.Options.UseForeColor = true;
            this.checkButton_BiB4.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.checkButton_BiB4.Checked = true;
            this.checkButton_BiB4.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkButton_BiB4.Location = new System.Drawing.Point(392, 0);
            this.checkButton_BiB4.Name = "checkButton_BiB4";
            this.checkButton_BiB4.Size = new System.Drawing.Size(96, 38);
            this.checkButton_BiB4.TabIndex = 3;
            this.checkButton_BiB4.Tag = "4";
            this.checkButton_BiB4.Text = "Größer ist besser";
            this.checkButton_BiB4.ToolTip = "Wenn dieses Element gesetzt ist, dann gewinnt bei einem Vergleich dieser Eigensch" +
    "aft\r\nimmer derjenige mit dem größeren Wert.\r\nDas wäre zum Beispiel beim Autoquar" +
    "tett bei der Fahrzeugleistung der Fall.";
            this.checkButton_BiB4.ToolTipAnchor = DevExpress.Utils.ToolTipAnchor.Object;
            this.checkButton_BiB4.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // textBox_Eigenschaft4
            // 
            this.textBox_Eigenschaft4.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox_Eigenschaft4.Location = new System.Drawing.Point(180, 0);
            this.textBox_Eigenschaft4.Name = "textBox_Eigenschaft4";
            this.textBox_Eigenschaft4.Size = new System.Drawing.Size(212, 43);
            this.textBox_Eigenschaft4.TabIndex = 1;
            this.textBox_Eigenschaft4.Tag = "4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 37);
            this.label4.TabIndex = 0;
            this.label4.Text = "Eigenschaft 4:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Eigenschaft3
            // 
            this.panel_Eigenschaft3.Controls.Add(this.checkButton_BiB3);
            this.panel_Eigenschaft3.Controls.Add(this.textBox_Eigenschaft3);
            this.panel_Eigenschaft3.Controls.Add(this.label3);
            this.panel_Eigenschaft3.Location = new System.Drawing.Point(17, 136);
            this.panel_Eigenschaft3.Name = "panel_Eigenschaft3";
            this.panel_Eigenschaft3.Size = new System.Drawing.Size(491, 38);
            this.panel_Eigenschaft3.TabIndex = 5;
            this.panel_Eigenschaft3.Tag = "3";
            // 
            // checkButton_BiB3
            // 
            this.checkButton_BiB3.AppearancePressed.BackColor = System.Drawing.Color.DarkMagenta;
            this.checkButton_BiB3.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.checkButton_BiB3.AppearancePressed.Options.UseBackColor = true;
            this.checkButton_BiB3.AppearancePressed.Options.UseForeColor = true;
            this.checkButton_BiB3.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.checkButton_BiB3.Checked = true;
            this.checkButton_BiB3.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkButton_BiB3.Location = new System.Drawing.Point(392, 0);
            this.checkButton_BiB3.Name = "checkButton_BiB3";
            this.checkButton_BiB3.Size = new System.Drawing.Size(96, 38);
            this.checkButton_BiB3.TabIndex = 3;
            this.checkButton_BiB3.Tag = "3";
            this.checkButton_BiB3.Text = "Größer ist besser";
            this.checkButton_BiB3.ToolTip = "Wenn dieses Element gesetzt ist, dann gewinnt bei einem Vergleich dieser Eigensch" +
    "aft\r\nimmer derjenige mit dem größeren Wert.\r\nDas wäre zum Beispiel beim Autoquar" +
    "tett bei der Fahrzeugleistung der Fall.";
            this.checkButton_BiB3.ToolTipAnchor = DevExpress.Utils.ToolTipAnchor.Object;
            this.checkButton_BiB3.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // textBox_Eigenschaft3
            // 
            this.textBox_Eigenschaft3.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox_Eigenschaft3.Location = new System.Drawing.Point(180, 0);
            this.textBox_Eigenschaft3.Name = "textBox_Eigenschaft3";
            this.textBox_Eigenschaft3.Size = new System.Drawing.Size(212, 43);
            this.textBox_Eigenschaft3.TabIndex = 1;
            this.textBox_Eigenschaft3.Tag = "3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 37);
            this.label3.TabIndex = 0;
            this.label3.Text = "Eigenschaft 3:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Eigenschaft2
            // 
            this.panel_Eigenschaft2.Controls.Add(this.checkButton_BiB);
            this.panel_Eigenschaft2.Controls.Add(this.textBox_Eigenschaft2);
            this.panel_Eigenschaft2.Controls.Add(this.label1);
            this.panel_Eigenschaft2.Location = new System.Drawing.Point(17, 92);
            this.panel_Eigenschaft2.Name = "panel_Eigenschaft2";
            this.panel_Eigenschaft2.Size = new System.Drawing.Size(491, 38);
            this.panel_Eigenschaft2.TabIndex = 4;
            this.panel_Eigenschaft2.Tag = "2";
            // 
            // checkButton_BiB
            // 
            this.checkButton_BiB.AppearancePressed.BackColor = System.Drawing.Color.DarkMagenta;
            this.checkButton_BiB.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.checkButton_BiB.AppearancePressed.Options.UseBackColor = true;
            this.checkButton_BiB.AppearancePressed.Options.UseForeColor = true;
            this.checkButton_BiB.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.checkButton_BiB.Checked = true;
            this.checkButton_BiB.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkButton_BiB.Location = new System.Drawing.Point(392, 0);
            this.checkButton_BiB.Name = "checkButton_BiB";
            this.checkButton_BiB.Size = new System.Drawing.Size(96, 38);
            this.checkButton_BiB.TabIndex = 2;
            this.checkButton_BiB.Tag = "2";
            this.checkButton_BiB.Text = "Größer ist besser";
            this.checkButton_BiB.ToolTip = "Wenn dieses Element gesetzt ist, dann gewinnt bei einem Vergleich dieser Eigensch" +
    "aft\r\nimmer derjenige mit dem größeren Wert.\r\nDas wäre zum Beispiel beim Autoquar" +
    "tett bei der Fahrzeugleistung der Fall.";
            this.checkButton_BiB.ToolTipAnchor = DevExpress.Utils.ToolTipAnchor.Object;
            this.checkButton_BiB.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // textBox_Eigenschaft2
            // 
            this.textBox_Eigenschaft2.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox_Eigenschaft2.Location = new System.Drawing.Point(180, 0);
            this.textBox_Eigenschaft2.Name = "textBox_Eigenschaft2";
            this.textBox_Eigenschaft2.Size = new System.Drawing.Size(212, 43);
            this.textBox_Eigenschaft2.TabIndex = 1;
            this.textBox_Eigenschaft2.Tag = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Eigenschaft 2:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Eigenschaft1
            // 
            this.panel_Eigenschaft1.Controls.Add(this.checkButton_BiB1);
            this.panel_Eigenschaft1.Controls.Add(this.textBox_Eigenschaft1);
            this.panel_Eigenschaft1.Controls.Add(this.label2);
            this.panel_Eigenschaft1.Location = new System.Drawing.Point(17, 48);
            this.panel_Eigenschaft1.Name = "panel_Eigenschaft1";
            this.panel_Eigenschaft1.Size = new System.Drawing.Size(491, 38);
            this.panel_Eigenschaft1.TabIndex = 3;
            this.panel_Eigenschaft1.Tag = "1";
            // 
            // checkButton_BiB1
            // 
            this.checkButton_BiB1.AppearancePressed.BackColor = System.Drawing.Color.DarkMagenta;
            this.checkButton_BiB1.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.checkButton_BiB1.AppearancePressed.Options.UseBackColor = true;
            this.checkButton_BiB1.AppearancePressed.Options.UseForeColor = true;
            this.checkButton_BiB1.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.checkButton_BiB1.Checked = true;
            this.checkButton_BiB1.Dock = System.Windows.Forms.DockStyle.Left;
            this.checkButton_BiB1.Location = new System.Drawing.Point(392, 0);
            this.checkButton_BiB1.Name = "checkButton_BiB1";
            this.checkButton_BiB1.Size = new System.Drawing.Size(96, 38);
            this.checkButton_BiB1.TabIndex = 3;
            this.checkButton_BiB1.Tag = "1";
            this.checkButton_BiB1.Text = "Größer ist besser";
            this.checkButton_BiB1.ToolTip = "Wenn dieses Element gesetzt ist, dann gewinnt bei einem Vergleich dieser Eigensch" +
    "aft\r\nimmer derjenige mit dem größeren Wert.\r\nDas wäre zum Beispiel beim Autoquar" +
    "tett bei der Fahrzeugleistung der Fall.";
            this.checkButton_BiB1.ToolTipAnchor = DevExpress.Utils.ToolTipAnchor.Object;
            this.checkButton_BiB1.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // textBox_Eigenschaft1
            // 
            this.textBox_Eigenschaft1.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox_Eigenschaft1.Location = new System.Drawing.Point(180, 0);
            this.textBox_Eigenschaft1.Name = "textBox_Eigenschaft1";
            this.textBox_Eigenschaft1.Size = new System.Drawing.Size(212, 43);
            this.textBox_Eigenschaft1.TabIndex = 1;
            this.textBox_Eigenschaft1.Tag = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 37);
            this.label2.TabIndex = 0;
            this.label2.Text = "Eigenschaft 1:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Karten
            // 
            this.label_Karten.Location = new System.Drawing.Point(283, 314);
            this.label_Karten.Name = "label_Karten";
            this.label_Karten.Size = new System.Drawing.Size(225, 37);
            this.label_Karten.TabIndex = 1;
            this.label_Karten.Tag = "3";
            this.label_Karten.Text = "Karten def. >";
            this.label_Karten.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Karten.Click += new System.EventHandler(this.label_QuartetteDefinieren_Click);
            this.label_Karten.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_Karten.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // label_Deckeigenschaften
            // 
            this.label_Deckeigenschaften.Location = new System.Drawing.Point(12, 314);
            this.label_Deckeigenschaften.Name = "label_Deckeigenschaften";
            this.label_Deckeigenschaften.Size = new System.Drawing.Size(269, 37);
            this.label_Deckeigenschaften.TabIndex = 0;
            this.label_Deckeigenschaften.Tag = "1";
            this.label_Deckeigenschaften.Text = "< Deck def.";
            this.label_Deckeigenschaften.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_Deckeigenschaften.Click += new System.EventHandler(this.label_QuartetteDefinieren_Click);
            this.label_Deckeigenschaften.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_Deckeigenschaften.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // panel_Eigenschaften
            // 
            this.panel_Eigenschaften.Controls.Add(this.label_QuartetteDefinieren);
            this.panel_Eigenschaften.Controls.Add(this.label_SpeicherortWählen);
            this.panel_Eigenschaften.Controls.Add(this.label_SpeicherortValue);
            this.panel_Eigenschaften.Controls.Add(this.label_Speicherort);
            this.panel_Eigenschaften.Controls.Add(this.label_DeckName);
            this.panel_Eigenschaften.Controls.Add(this.label_AnzahlEigenschaften);
            this.panel_Eigenschaften.Controls.Add(this.numericUpDown_AnzahlQuartetts);
            this.panel_Eigenschaften.Controls.Add(this.label_AnzahlQuartetts);
            this.panel_Eigenschaften.Controls.Add(this.numericUpDown_AnzahlEiggenschaften);
            this.panel_Eigenschaften.Controls.Add(this.textBox_DeckName);
            this.panel_Eigenschaften.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Eigenschaften.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel_Eigenschaften.Location = new System.Drawing.Point(0, 0);
            this.panel_Eigenschaften.Name = "panel_Eigenschaften";
            this.panel_Eigenschaften.Size = new System.Drawing.Size(521, 400);
            this.panel_Eigenschaften.TabIndex = 3;
            this.panel_Eigenschaften.Tag = "1";
            // 
            // label_QuartetteDefinieren
            // 
            this.label_QuartetteDefinieren.AutoSize = true;
            this.label_QuartetteDefinieren.Location = new System.Drawing.Point(230, 300);
            this.label_QuartetteDefinieren.Name = "label_QuartetteDefinieren";
            this.label_QuartetteDefinieren.Size = new System.Drawing.Size(281, 37);
            this.label_QuartetteDefinieren.TabIndex = 10;
            this.label_QuartetteDefinieren.Tag = "2";
            this.label_QuartetteDefinieren.Text = "Quartette definieren >";
            this.label_QuartetteDefinieren.Click += new System.EventHandler(this.label_QuartetteDefinieren_Click);
            this.label_QuartetteDefinieren.MouseLeave += new System.EventHandler(this.label_NewQuartett_MouseLeave);
            this.label_QuartetteDefinieren.MouseHover += new System.EventHandler(this.label_NewQuartett_MouseHover);
            // 
            // label_SpeicherortWählen
            // 
            this.label_SpeicherortWählen.Image = global::QuartettSim2k18.Properties.Resources.Öffnen_32;
            this.label_SpeicherortWählen.Location = new System.Drawing.Point(455, 217);
            this.label_SpeicherortWählen.Name = "label_SpeicherortWählen";
            this.label_SpeicherortWählen.Size = new System.Drawing.Size(53, 37);
            this.label_SpeicherortWählen.TabIndex = 9;
            this.label_SpeicherortWählen.Click += new System.EventHandler(this.SelectSavePath);
            // 
            // label_SpeicherortValue
            // 
            this.label_SpeicherortValue.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SpeicherortValue.Location = new System.Drawing.Point(19, 263);
            this.label_SpeicherortValue.Name = "label_SpeicherortValue";
            this.label_SpeicherortValue.Size = new System.Drawing.Size(489, 37);
            this.label_SpeicherortValue.TabIndex = 8;
            // 
            // label_Speicherort
            // 
            this.label_Speicherort.AutoSize = true;
            this.label_Speicherort.Location = new System.Drawing.Point(12, 217);
            this.label_Speicherort.Name = "label_Speicherort";
            this.label_Speicherort.Size = new System.Drawing.Size(158, 37);
            this.label_Speicherort.TabIndex = 6;
            this.label_Speicherort.Text = "Speicherort:";
            // 
            // label_DeckName
            // 
            this.label_DeckName.Location = new System.Drawing.Point(12, 51);
            this.label_DeckName.Name = "label_DeckName";
            this.label_DeckName.Size = new System.Drawing.Size(101, 37);
            this.label_DeckName.TabIndex = 0;
            this.label_DeckName.Text = "Name: ";
            // 
            // label_AnzahlEigenschaften
            // 
            this.label_AnzahlEigenschaften.AutoSize = true;
            this.label_AnzahlEigenschaften.Location = new System.Drawing.Point(12, 107);
            this.label_AnzahlEigenschaften.Name = "label_AnzahlEigenschaften";
            this.label_AnzahlEigenschaften.Size = new System.Drawing.Size(437, 37);
            this.label_AnzahlEigenschaften.TabIndex = 2;
            this.label_AnzahlEigenschaften.Text = "Anzahl der Eigenschaften pro Karte:";
            // 
            // numericUpDown_AnzahlQuartetts
            // 
            this.numericUpDown_AnzahlQuartetts.Location = new System.Drawing.Point(455, 165);
            this.numericUpDown_AnzahlQuartetts.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown_AnzahlQuartetts.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDown_AnzahlQuartetts.Name = "numericUpDown_AnzahlQuartetts";
            this.numericUpDown_AnzahlQuartetts.Size = new System.Drawing.Size(53, 43);
            this.numericUpDown_AnzahlQuartetts.TabIndex = 5;
            this.numericUpDown_AnzahlQuartetts.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // label_AnzahlQuartetts
            // 
            this.label_AnzahlQuartetts.AutoSize = true;
            this.label_AnzahlQuartetts.Location = new System.Drawing.Point(12, 165);
            this.label_AnzahlQuartetts.Name = "label_AnzahlQuartetts";
            this.label_AnzahlQuartetts.Size = new System.Drawing.Size(269, 37);
            this.label_AnzahlQuartetts.TabIndex = 4;
            this.label_AnzahlQuartetts.Text = "Anzahl der Quartette:";
            // 
            // numericUpDown_AnzahlEiggenschaften
            // 
            this.numericUpDown_AnzahlEiggenschaften.Location = new System.Drawing.Point(455, 107);
            this.numericUpDown_AnzahlEiggenschaften.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.numericUpDown_AnzahlEiggenschaften.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_AnzahlEiggenschaften.Name = "numericUpDown_AnzahlEiggenschaften";
            this.numericUpDown_AnzahlEiggenschaften.Size = new System.Drawing.Size(53, 43);
            this.numericUpDown_AnzahlEiggenschaften.TabIndex = 3;
            this.numericUpDown_AnzahlEiggenschaften.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // textBox_DeckName
            // 
            this.textBox_DeckName.Location = new System.Drawing.Point(175, 48);
            this.textBox_DeckName.Name = "textBox_DeckName";
            this.textBox_DeckName.Size = new System.Drawing.Size(333, 43);
            this.textBox_DeckName.TabIndex = 1;
            // 
            // frmDeckEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(36)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(521, 478);
            this.Controls.Add(this.panel_NewQuartett);
            this.Controls.Add(this.panel_Controls);
            this.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "frmDeckEdit";
            this.Text = "frmDeckEdit";
            this.panel_Controls.ResumeLayout(false);
            this.panel_NewQuartett.ResumeLayout(false);
            this.panel_KartenDef.ResumeLayout(false);
            this.panel_Karteninfos.ResumeLayout(false);
            this.panel_Karteninfos.PerformLayout();
            this.panel_KartenInhalte.ResumeLayout(false);
            this.panel_KartenInhalte.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Image)).EndInit();
            this.panel_QuartettDef.ResumeLayout(false);
            this.panel_Eigenschaft6.ResumeLayout(false);
            this.panel_Eigenschaft6.PerformLayout();
            this.panel_Eigenschaft5.ResumeLayout(false);
            this.panel_Eigenschaft5.PerformLayout();
            this.panel_Eigenschaft4.ResumeLayout(false);
            this.panel_Eigenschaft4.PerformLayout();
            this.panel_Eigenschaft3.ResumeLayout(false);
            this.panel_Eigenschaft3.PerformLayout();
            this.panel_Eigenschaft2.ResumeLayout(false);
            this.panel_Eigenschaft2.PerformLayout();
            this.panel_Eigenschaft1.ResumeLayout(false);
            this.panel_Eigenschaft1.PerformLayout();
            this.panel_Eigenschaften.ResumeLayout(false);
            this.panel_Eigenschaften.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_AnzahlQuartetts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_AnzahlEiggenschaften)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Controls;
        private System.Windows.Forms.Label label_DeckLaden;
        private System.Windows.Forms.Label label_NewDeck;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Panel panel_NewQuartett;
        private System.Windows.Forms.TextBox textBox_DeckName;
        private System.Windows.Forms.Label label_Caption;
        private System.Windows.Forms.Panel panel_Eigenschaften;
        private System.Windows.Forms.NumericUpDown numericUpDown_AnzahlQuartetts;
        private System.Windows.Forms.Label label_AnzahlQuartetts;
        private System.Windows.Forms.NumericUpDown numericUpDown_AnzahlEiggenschaften;
        private System.Windows.Forms.Label label_AnzahlEigenschaften;
        private System.Windows.Forms.Label label_Speicherort;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_Speicherort;
        private System.Windows.Forms.Label label_SpeicherortWählen;
        private System.Windows.Forms.Label label_SpeicherortValue;
        private System.Windows.Forms.Label label_QuartetteDefinieren;
        private System.Windows.Forms.Panel panel_QuartettDef;
        private System.Windows.Forms.Label label_Karten;
        private System.Windows.Forms.Label label_Deckeigenschaften;
        private System.Windows.Forms.Label label_DeckName;
        private System.Windows.Forms.Panel panel_Eigenschaft3;
        private System.Windows.Forms.TextBox textBox_Eigenschaft3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_Eigenschaft2;
        private System.Windows.Forms.TextBox textBox_Eigenschaft2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_Eigenschaft1;
        private System.Windows.Forms.TextBox textBox_Eigenschaft1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel_Eigenschaft4;
        private System.Windows.Forms.TextBox textBox_Eigenschaft4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_Eigenschaft6;
        private System.Windows.Forms.TextBox textBox_Eigenschaft6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel_Eigenschaft5;
        private System.Windows.Forms.TextBox textBox_Eigenschaft5;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.CheckButton checkButton_BiB;
        private DevExpress.XtraEditors.CheckButton checkButton_BiB6;
        private DevExpress.XtraEditors.CheckButton checkButton_BiB5;
        private DevExpress.XtraEditors.CheckButton checkButton_BiB4;
        private DevExpress.XtraEditors.CheckButton checkButton_BiB3;
        private DevExpress.XtraEditors.CheckButton checkButton_BiB1;
        private System.Windows.Forms.Panel panel_KartenDef;
        private System.Windows.Forms.Label label_Zwischenspeichern;
        private System.Windows.Forms.Panel panel_Karteninfos;
        private System.Windows.Forms.Label label_QuartettDef;
        private System.Windows.Forms.Panel panel_KartenInhalte;
        private System.Windows.Forms.Label label_Kartennummer;
        private System.Windows.Forms.Button button_NextQuartett;
        private System.Windows.Forms.TextBox textBox_Quartettname;
        private System.Windows.Forms.Label label_Quartettname;
        private System.Windows.Forms.TextBox textBox_DisplayValue6;
        private System.Windows.Forms.TextBox textBox_Value6;
        private System.Windows.Forms.Label label_P6;
        private System.Windows.Forms.TextBox textBox_DisplayValue5;
        private System.Windows.Forms.TextBox textBox_Value5;
        private System.Windows.Forms.Label label_P5;
        private System.Windows.Forms.TextBox textBox_DisplayValue4;
        private System.Windows.Forms.TextBox textBox_Value4;
        private System.Windows.Forms.Label label_P4;
        private System.Windows.Forms.TextBox textBox_DisplayValue3;
        private System.Windows.Forms.TextBox textBox_Value3;
        private System.Windows.Forms.Label label_P3;
        private System.Windows.Forms.TextBox textBox_DisplayValue2;
        private System.Windows.Forms.TextBox textBox_Value2;
        private System.Windows.Forms.Label label_P2;
        private System.Windows.Forms.TextBox textBox_DisplayValue1;
        private System.Windows.Forms.TextBox textBox_Value1;
        private System.Windows.Forms.Label label_P1;
        private System.Windows.Forms.Button button_BildWählen;
        private System.Windows.Forms.PictureBox pictureBox_Image;
        private System.Windows.Forms.Button button_NextCard;
        private System.Windows.Forms.TextBox textBox_CardName;
    }
}